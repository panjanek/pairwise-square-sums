"""Budgeted exhaustive continuation. Resume repeats only unfinished blocks.

All paths and the original deadline are recorded in manifest.json. Production
blocks always start fresh; raw C checkpoint counters are not used for coverage.
"""
from pathlib import Path
from datetime import datetime, timezone
from math import isqrt
from itertools import combinations
import argparse
import ctypes
import fcntl
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
STOP = False


def utc(t=None):
    return datetime.fromtimestamp(time.time() if t is None else t, timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024*1024), b''):
            h.update(part)
    return h.hexdigest()


def atomic(path, value):
    temp = path.with_suffix(path.suffix+'.tmp')
    with temp.open('w') as f:
        json.dump(value, f, indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    for attempt in range(40):
        try:
            os.replace(temp, path)
            return
        except PermissionError:
            if attempt == 39:
                raise
            time.sleep(0.05 if attempt < 10 else 0.2)


def stop(signum, frame):
    global STOP
    STOP = True


def child_setup():
    # Stop a worker if its controller disappears unexpectedly.
    libc = ctypes.CDLL(None)
    if libc.prctl(1, signal.SIGTERM, 0, 0, 0) != 0:
        os._exit(127)
    if os.getppid() == 1:
        os._exit(127)


def parse_result(err, lo, hi, checkpoint):
    text = err.read_text()
    if any(s in text for s in ('FATAL:', 'VERIFY FAILED', 'BAD 4-set')):
        raise ValueError('Search reported an error: '+str(err))
    total_lines = [line for line in text.splitlines() if line.startswith('TOTAL:')]
    assert len(total_lines) == 1
    totals = {k: int(v) for k, v in re.findall(r'([\w-]+)=(\d+)', total_lines[0])}
    assert totals['S_done'] == hi-lo, (totals, lo, hi)
    cap = re.search(r'CAPACITY: reps=(\d+)/(\d+) divisors=(\d+)/(\d+) extensions=(\d+)/(\d+)', text)
    assert cap is not None
    maxima = {key: {'used': int(cap[2*i+1]), 'limit': int(cap[2*i+2])}
              for i, key in enumerate(('representations', 'divisors', 'extensions'))}
    assert all(c['used'] <= c['limit'] for c in maxima.values())
    cp = checkpoint.read_text().splitlines()
    assert cp[-1] == 'DONE' and cp[0] == 's4ckpt v1'
    a, b, threads, chunk = map(int, cp[1].split())
    assert (a, b) == (lo, hi) and len(cp) == threads+3
    for i, line in enumerate(cp[2:-1]):
        vals = list(map(int, line.split()))
        assert vals[0] == i and vals[1] == vals[2] == lo+(hi-lo)*(i+1)//threads
    return totals, maxima


class Search:
    def __init__(self, directory, budget_start, hours, reserve, threads, start, previous_directory=None):
        self.out = directory.resolve(); self.out.mkdir(parents=True, exist_ok=True)
        self.lock = (self.out/'run.lock').open('a')
        fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        self.child = None; self.current = None
        self.path = self.out/'manifest.json'
        self.binary = self.out/'s4'
        if self.path.exists():
            self.m = json.loads(self.path.read_text())
            assert self.m['threads'] == threads
        else:
            preflight = json.loads((self.out/'preflight/summary.json').read_text())
            assert preflight['passed'] and preflight['source_sha256'] == sha(ROOT/'s4.c')
            assert preflight['binary_sha256'] == sha(self.out/'preflight/s4')
            previous = None
            if previous_directory is not None:
                prior = previous_directory.resolve()
                prior_audit = json.loads((prior/'audit.json').read_text())
                prior_status = json.loads((prior/'status.json').read_text())
                assert prior_audit['passed'] and not prior_audit['positive_sextuples']
                assert prior_status.get('audit_passed') and prior_status['status'] in ('budget_exhausted', 'completed')
                assert prior_audit['frontier'] == prior_status['frontier'] == start
                previous = {'directory': str(prior), 'frontier': start,
                            'files': {name: sha(prior/name) for name in
                                      ('manifest.json', 'audit.json', 'near-misses.json', 'final-independent-verification.json')}}
            shutil.copy2(self.out/'preflight/s4', self.binary)
            sources = ['s4.c', 'exhaustive/run_exhaustive.py', 'exhaustive/audit_exhaustive.py',
                       'exhaustive/test_preflight.py', 'noneuler/classify.py']
            snapshots = self.out/'sources'; snapshots.mkdir(exist_ok=True)
            for name in sources:
                dest = snapshots/name; dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT/name, dest)
            self.m = {'budget_started_at': utc(budget_start), 'budget_started_epoch': budget_start,
                      'launched_at': utc(), 'deadline_epoch': budget_start+hours*3600,
                      'deadline_at': utc(budget_start+hours*3600),
                      'search_deadline_epoch': budget_start+hours*3600-reserve,
                      'search_deadline_at': utc(budget_start+hours*3600-reserve),
                      'threads': threads, 'start': start, 'chunk_log2': 20,
                      'source_sha256': {p: sha(ROOT/p) for p in sources},
                      'binary_sha256': sha(self.binary),
                      'compiler': subprocess.check_output(['gcc', '--version'], text=True).splitlines()[0],
                      'historical_data_sha256': '1dca944413520b5cf1596c4c5820b454e1037c13177ff479d39435e5ee4d5301',
                      'completed_blocks': [], 'attempts': []}
            if previous is not None:
                self.m['previous_run'] = previous
            atomic(self.path, self.m)
        assert sha(self.binary) == self.m['binary_sha256']
        for name, digest in self.m['source_sha256'].items():
            assert sha(ROOT/name) == digest, 'Source changed since launch: '+name
        for attempt in self.m['attempts']:
            if 'returncode' not in attempt:
                attempt.update({'complete': False, 'returncode': None, 'abandoned_at': utc()})
        atomic(self.path, self.m)

    def frontier(self):
        frontier = self.m['start']
        for block in self.m['completed_blocks']:
            assert block['lo'] == frontier
            frontier = block['hi']
        return frontier

    def status(self, state, **extra):
        blocks = self.m['completed_blocks']
        value = {'status': state, 'updated_at': utc(), 'pid': os.getpid(),
                 'child_pid': self.child.pid if self.child else None,
                 'budget_started_at': self.m['budget_started_at'], 'launched_at': self.m['launched_at'],
                 'deadline_at': self.m['deadline_at'], 'search_deadline_at': self.m['search_deadline_at'],
                 'completed_blocks': len(blocks), 'frontier': self.frontier(),
                 'searched_S': self.frontier()-self.m['start'], 'current_block': self.current,
                 'five_sets': sum(b['totals']['5-sets'] for b in blocks),
                 'six_sets': sum(b['totals']['6-sets'] for b in blocks),
                 'multi_lines': sum(b['totals']['multi-ext-4sets'] for b in blocks), **extra}
        atomic(self.out/'status.json', value)

    def solution(self):
        path = self.out/'SIXSET_FOUND.txt'
        if not path.exists():
            return None
        for line in path.read_text().splitlines():
            if not line.startswith('!!!!!!!! FOUND 6-SET:'):
                continue
            values = list(map(int, re.search(r'\[([^]]+)\]', line)[1].split(',')))
            assert len(values) == len(set(values)) == 6 and min(values)>0
            assert all(isqrt(a+b)**2 == a+b for a, b in combinations(values, 2))
            record = {'values': sorted(values), 'verified_at': utc(), 'line': line}
            atomic(self.out/'solution.json', record)
            return record
        return None

    def block(self, hi):
        num = len(self.m['attempts'])+1
        name = 'block-%04d' % num
        lo = self.frontier()
        record = {'id': name, 'lo': lo, 'hi': hi, 'started_at': utc()}
        self.m['attempts'].append(record); self.current = record
        atomic(self.path, self.m)
        output = self.out/(name+'.out'); err = self.out/(name+'.err'); cp = self.out/(name+'.ckpt')
        args = [str(self.binary), str(lo), str(hi), str(self.m['threads']), '20',
                '--verify', '--out', str(output), '--ckpt', str(cp)]
        record['command'] = args
        began = time.monotonic(); sent = None
        with err.open('w') as log:
            self.child = subprocess.Popen(args, cwd=self.out, stdout=subprocess.DEVNULL,
                                          stderr=log, preexec_fn=child_setup)
            while self.child.poll() is None:
                self.status('running')
                if (STOP or time.time()>=self.m['search_deadline_epoch'] or self.solution()) and sent is None:
                    self.child.terminate(); sent = time.monotonic()
                if sent is not None and time.monotonic()-sent > 10:
                    self.child.kill()
                time.sleep(2)
            rc = self.child.returncode; self.child = None
        record.update({'returncode': rc, 'complete': False, 'ended_at': utc(),
                       'elapsed_seconds': time.monotonic()-began})
        if rc == 0:
            totals, maxima = parse_result(err, lo, hi, cp)
            record.update({'complete': True, 'totals': totals, 'capacity_maxima': maxima,
                           'output_sha256': sha(output), 'stderr_sha256': sha(err), 'checkpoint_sha256': sha(cp)})
            self.m['completed_blocks'].append(dict(record))
        atomic(self.path, self.m); self.current = None
        if rc != 0 and sent is None:
            raise RuntimeError('Worker failed: '+name+' exit '+str(rc))
        print('BLOCK', json.dumps(record), flush=True)
        return rc == 0

    def run(self):
        end = self.m['search_deadline_epoch']
        self.status('running')
        while time.time() < end-20 and not STOP and not self.solution():
            blocks = self.m['completed_blocks'][-5:]
            rate = sum(b['elapsed_seconds'] for b in blocks)/sum(b['hi']-b['lo'] for b in blocks) if blocks else 36e-9
            available = end-time.time()-15
            width = min(5*10**9, int(available/(rate*1.15))//10**8*10**8)
            if width < 10**8:
                break
            if not self.block(self.frontier()+width):
                break
        state = 'solution_found' if self.solution() else 'interrupted' if STOP else 'budget_exhausted'
        self.status('auditing', search_result=state)
        with (self.out/'audit.log').open('a') as log:
            audit = subprocess.run(['python3', str(ROOT/'exhaustive/audit_exhaustive.py'), str(self.out)],
                                   stdout=log, stderr=log,
                                   timeout=max(30, self.m['deadline_epoch']-time.time()-10))
        if audit.returncode != 0:
            raise RuntimeError('Final audit failed; see audit.log')
        self.status(state, audit_passed=True, finished_at=utc())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--directory', type=Path, required=True)
    ap.add_argument('--budget-start', required=True)
    ap.add_argument('--hours', type=float, default=9)
    ap.add_argument('--reserve-seconds', type=int, default=1500)
    ap.add_argument('--threads', type=int, default=16)
    ap.add_argument('--start', type=int, default=1001000000000)
    ap.add_argument('--previous-directory', type=Path)
    args = ap.parse_args()
    assert 0 < args.hours <= 10 and 1 <= args.threads <= 16
    began = datetime.fromisoformat(args.budget_start).timestamp()
    signal.signal(signal.SIGINT, stop); signal.signal(signal.SIGTERM, stop)
    search = None
    try:
        search = Search(args.directory, began, args.hours, args.reserve_seconds, args.threads, args.start, args.previous_directory)
        search.run()
    except Exception:
        if search:
            if search.child and search.child.poll() is None:
                search.child.terminate()
                try:
                    search.child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    search.child.kill(); search.child.wait()
            search.status('failed', error=traceback.format_exc())
        raise


if __name__ == '__main__':
    main()

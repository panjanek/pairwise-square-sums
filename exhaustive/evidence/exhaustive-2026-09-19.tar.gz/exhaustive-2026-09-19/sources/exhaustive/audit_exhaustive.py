"""Independently check saved exhaustive results, coverage, and near misses."""
from pathlib import Path
from datetime import datetime, timezone
from itertools import combinations
from functools import reduce, lru_cache
from math import gcd, isqrt
import hashlib
import json
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'noneuler'))
from classify import load, sqf_scale, latin_square, euler_signs


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def square(n):
    return n >= 0 and isqrt(n)**2 == n


@lru_cache(maxsize=None)
def scale(g):
    return sqf_scale(g)**2


def audit(directory):
    started = time.monotonic()
    m = json.loads((directory/'manifest.json').read_text())
    for name, sha in m['source_sha256'].items():
        assert digest(directory/'sources'/name) == sha, name
    assert digest(directory/'s4') == m['binary_sha256']
    historical = Path.home()/'ps/all_1e12.out'
    assert digest(historical) == m['historical_data_sha256']
    baseline = load(str(historical))
    assert len(baseline) == 430
    original_baseline = dict(baseline)
    prior_five_count = 1374167
    predecessor = m.get('previous_run')
    expected_frontier = m['start']
    visited = set()
    while predecessor is not None:
        prior = Path(predecessor['directory'])
        assert str(prior) not in visited, 'Cyclic run ancestry'
        visited.add(str(prior))
        for name, sha in predecessor['files'].items():
            assert digest(prior/name) == sha, 'Predecessor changed: '+str(prior/name)
        prior_manifest = json.loads((prior/'manifest.json').read_text())
        prior_audit = json.loads((prior/'audit.json').read_text())
        prior_check = json.loads((prior/'final-independent-verification.json').read_text())
        assert prior_audit['passed'] and prior_check['passed'] and not prior_audit['positive_sextuples']
        assert prior_audit['frontier'] == predecessor['frontier'] == expected_frontier
        cursor = prior_manifest['start']
        for block in prior_manifest['completed_blocks']:
            assert block['lo'] == cursor and block['complete'] and block['returncode'] == 0
            cursor = block['hi']
        assert cursor == expected_frontier
        for record in json.loads((prior/'near-misses.json').read_text()):
            values = tuple(record['values'])
            assert len(values) == len(set(values)) == 6 and min(values)>0
            assert sum(square(a+b) for a, b in combinations(values, 2)) == 14
            baseline[values] = tuple(record['nonsquare_pair'])
        prior_five_count += prior_audit['unique_five_sets']
        predecessor = prior_manifest.get('previous_run')
        expected_frontier = prior_manifest['start']
    assert expected_frontier == 1001000000000, 'Ancestry does not reach original verified frontier'
    five = set(); sextuples = set(); pseudos = {}; raw = {'five': 0, 'multi': 0, 'six': 0}
    all_capacity = {key: 0 for key in ('representations', 'divisors', 'extensions')}
    frontier = m['start']
    interval_lo = frontier if m.get('previous_run') else 10**12
    sources = [] if m.get('previous_run') else [(directory/'preflight/frontier.out', 10**12, frontier, None)]
    for block in m['completed_blocks']:
        assert block['complete'] and block['returncode'] == 0 and block['lo'] == frontier
        frontier = block['hi']; stem = directory/block['id']
        for suffix, key in [('.out', 'output_sha256'), ('.err', 'stderr_sha256'), ('.ckpt', 'checkpoint_sha256')]:
            assert digest(stem.with_suffix(suffix)) == block[key]
        err = stem.with_suffix('.err').read_text()
        assert not any(marker in err for marker in ('FATAL:', 'VERIFY FAILED', 'BAD 4-set'))
        totals = re.findall(r'^TOTAL: (.*)$', err, re.M)
        assert len(totals) == 1
        stats = {key: int(value) for key, value in re.findall(r'([\w-]+)=(\d+)', totals[0])}
        assert stats == block['totals'] and stats['S_done'] == block['hi']-block['lo']
        cp = stem.with_suffix('.ckpt').read_text().splitlines()
        assert cp[0] == 's4ckpt v1' and cp[-1] == 'DONE'
        lo, hi, nt, width = map(int, cp[1].split())
        assert (lo, hi, nt, width) == (block['lo'], block['hi'], m['threads'], 1<<m['chunk_log2'])
        assert len(cp) == nt+3
        for thread, row in enumerate(cp[2:-1]):
            values = list(map(int, row.split()))
            assert values[0] == thread and values[1] == values[2] == lo+(hi-lo)*(thread+1)//nt
        caps = re.search(r'CAPACITY: reps=(\d+)/(\d+) divisors=(\d+)/(\d+) extensions=(\d+)/(\d+)', err)
        assert caps
        for i, name in enumerate(all_capacity):
            used, limit = map(int, (caps[2*i+1], caps[2*i+2]))
            assert used <= limit and block['capacity_maxima'][name] == {'used': used, 'limit': limit}
            all_capacity[name] = max(all_capacity[name], used)
        sources.append((stem.with_suffix('.out'), lo, hi, stats))
    for path, lo, hi, stats in sources:
        local = {'five': 0, 'multi': 0, 'six': 0}
        for line in path.read_text().splitlines():
            assert 'VERIFY FAILED' not in line
            s = int(re.search(r'S=(\d+)', line)[1]); assert lo <= s < hi
            if line.startswith('5:'):
                vals = tuple(sorted(map(int, re.search(r'\[([^]]+)\]', line)[1].split(','))))
                assert len(vals) == len(set(vals)) == 5 and min(vals)>0
                assert sum(vals[:4]) == s and all(square(a+b) for a, b in combinations(vals, 2))
                five.add(vals); local['five'] += 1
            elif line.startswith('M:'):
                match = re.fullmatch(r'M: \[([\d,]+)\] ext=\[([\d,]+)\] S=(\d+)', line)
                assert match
                four = tuple(map(int, match[1].split(','))); ext = tuple(map(int, match[2].split(',')))
                assert len(four) == len(set(four)) == 4 and min(four)>0 and sum(four) == s
                assert len(ext) == len(set(ext)) >= 2 and min(ext)>0 and not set(ext)&set(four)
                assert all(square(a+b) for a, b in combinations(four, 2))
                assert all(square(a+b) for a in four for b in ext)
                for a, b in combinations(ext, 2):
                    vals = four+(a, b)
                    if square(a+b):
                        sextuples.add(tuple(sorted(vals)))
                    else:
                        k2 = scale(reduce(gcd, vals))
                        primitive = tuple(sorted(v//k2 for v in vals))
                        assert sum(square(x+y) for x, y in combinations(primitive, 2)) == 14
                        pseudos[primitive] = tuple(sorted((a//k2, b//k2)))
                local['multi'] += 1
            elif line.startswith('!!!!!!!! FOUND 6-SET:'):
                vals = tuple(sorted(map(int, re.search(r'\[([^]]+)\]', line)[1].split(','))))
                assert len(vals) == len(set(vals)) == 6 and min(vals)>0
                assert all(square(a+b) for a, b in combinations(vals, 2))
                sextuples.add(vals); local['six'] += 1
            else:
                raise AssertionError('Unrecognized output: '+line)
        if stats:
            assert (local['five'], local['multi'], local['six']) == (
                stats['5-sets'], stats['multi-ext-4sets'], stats['6-sets'])
        for key in raw:
            raw[key] += local[key]
    # A hit in an interrupted interval is valid, even though that interval adds no coverage.
    partial_solutions = directory/'SIXSET_FOUND.txt'
    if partial_solutions.exists():
        for line in partial_solutions.read_text().splitlines():
            assert line.startswith('!!!!!!!! FOUND 6-SET:')
            vals = tuple(sorted(map(int, re.search(r'\[([^]]+)\]', line)[1].split(','))))
            assert len(vals) == len(set(vals)) == 6 and min(vals)>0
            assert all(square(a+b) for a, b in combinations(vals, 2))
            sextuples.add(vals)
    records = []; hist = {}
    for vals, bad in sorted(pseudos.items()):
        others = [v for v in vals if v not in bad]
        euler_count = 0
        for a in others:
            x = bad+(a,); y = tuple(v for v in vals if v not in x)
            _, roots = latin_square(x, y)
            euler_count += euler_signs(roots) is not None
        is_new = vals not in baseline
        if is_new:
            hist[euler_count] = hist.get(euler_count, 0)+1
        records.append({'values': vals, 'nonsquare_pair': bad, 'new_vs_S_lt_1e12': vals not in original_baseline,
                        'new_vs_prior_frontier': is_new,
                        'square_total': square(sum(vals)), 'euler_squares': euler_count})
    new = [r for r in records if r['new_vs_prior_frontier']]
    cumulative = dict(baseline); cumulative.update(pseudos)
    result = {'passed': True, 'audited_at': datetime.now(timezone.utc).isoformat(),
              'frontier': frontier, 'new_interval_lo': interval_lo, 'new_interval_hi': frontier,
              'baseline_primitive_near_misses': len(baseline),
              'cumulative_primitive_near_misses': len(cumulative),
              'cumulative_square_total_near_misses': sum(square(sum(v)) for v in cumulative),
              'cumulative_unique_five_sets': prior_five_count+len(five),
              'completed_blocks': len(m['completed_blocks']), 'attempted_blocks': len(m['attempts']),
              'raw_counts_including_frontier_preflight': raw, 'unique_five_sets': len(five),
              'duplicate_five_lines': raw['five']-len(five),
              'positive_sextuples': sorted(sextuples), 'primitive_near_misses_in_interval': len(records),
              'new_primitive_near_misses_vs_S_lt_1e12': sum(r['new_vs_S_lt_1e12'] for r in records),
              'new_primitive_near_misses': len(new),
              'new_square_total_near_misses': sum(r['square_total'] for r in new),
              'new_near_miss_euler_histogram': hist, 'capacity_high_water': all_capacity,
              'historical_data_sha256': m['historical_data_sha256'],
              'audit_seconds': time.monotonic()-started}
    (directory/'near-misses.json').write_text(json.dumps(records, indent=2)+'\n')
    (directory/'audit.json').write_text(json.dumps(result, indent=2)+'\n')
    lines = ['# Exhaustive continuation: audited findings', '',
             '**Positive sextuples found: %d.**' % len(sextuples), '',
             'Budget began: '+m['budget_started_at']+'. Deadline: '+m['deadline_at']+'.', '',
             'Audit completed: '+result['audited_at']+'.', '',
             '## Coverage', '',
             f'Completed {len(m["completed_blocks"])} blocks; continuous coverage reaches **S < {frontier:,}**.', '',
             f'S is the sum of the four smallest members. This batch adds [{interval_lo:,}, {frontier:,}) '
             'to the earlier audited coverage. The original S < 10^12 census includes its nine repaired '
             'singleton boundaries. Source snapshots and hashes link this batch to its predecessors.', '',
             'Only complete intervals contribute to the frontier. Incomplete attempts remain in the manifest.', '',
             ('If no positive sextuple is listed, the computational exclusion implies the third-largest '
              f'member, and hence the largest, exceeds {frontier/4:,.0f}. '
              'This extends the existing computational census; it is not an independent rerun of all historical coverage.'), '',
             '## Verified outputs', '',
             f'- {raw["five"]:,} five-set lines; {len(five):,} distinct five-sets.',
             f'- {raw["multi"]:,} multi-extension quadruple lines.',
             f'- {len(records):,} primitive 14/15 configurations in this interval.',
             f'- {len(new):,} primitive configurations absent from all earlier audited coverage; '
             f'{sum(r["square_total"] for r in new):,} have square total.',
             f'- Cumulative catalog: {len(cumulative):,} primitive near misses and {prior_five_count+len(five):,} unique five-sets.',
             '- Euler-square count histogram for new configurations: '+str(hist)+'.', '',
             'Every reported five-set and near miss was checked with Python integer square roots. '
             'Completed interval bounds, checkpoint endpoints, counters, capacity maxima, and file hashes passed the audit.', '',
             '## Evidence', '',
             '- `manifest.json`: commands, contiguous intervals, checksums, and timings.',
             '- `audit.json`: independent verification summary.',
             '- `near-misses.json`: primitive values, missing edge, novelty, and Euler-square counts.',
             '- `preflight/`: reference equivalence, forced capacity failures, and checkpoint recovery checks.', '',
             'Capacity high-water marks: '+str(all_capacity)+'.', '']
    for vals in sorted(sextuples):
        lines.extend(['## Positive sextuple', '', str(vals), ''])
    (directory/'FINDINGS.md').write_text('\n'.join(lines))
    print(json.dumps(result), flush=True)
    return result


if __name__ == '__main__':
    audit(Path(sys.argv[1]).resolve())

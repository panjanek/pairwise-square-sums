"""Build and validate the exhaustive census without launching the long run."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'runs/exhaustive-2026-09-16/preflight'


def build(name='s4', extra=()):
    binary = OUT / name
    with (OUT / (name + '-build.log')).open('w') as log:
        subprocess.run(['gcc', '-O3', '-march=native', '-Wall', '-Wextra', *extra,
                        '-o', str(binary), str(ROOT / 's4.c'), '-lm', '-lpthread'],
                       stdout=log, stderr=log, check=True)
    return binary


def run(binary, name, lo, hi, *extra, expected=0):
    started = time.monotonic()
    with (OUT / (name + '.out')).open('w') as out, (OUT / (name + '.err')).open('w') as err:
        p = subprocess.run([str(binary), str(lo), str(hi), '16', '20', *map(str, extra)],
                           cwd=OUT, stdout=out, stderr=err)
    assert p.returncode == expected, (name, p.returncode)
    print(name, 'passed', round(time.monotonic()-started, 2), flush=True)


def lines(path):
    return sorted(Path(path).read_text().splitlines())


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / 'summary.json').exists(), 'Preflight already completed; preserve its evidence'
    binary = build()
    run(binary, 'small', 1, 10**9, '--verify')
    assert lines(OUT/'small.out') == lines(ROOT/'review-2026-09-15/s4_1e9.out')
    # Exercise every formerly silent capacity limit with intentionally tiny test caps.
    for kind, define, expected_message in [
        ('reps', 'S4_MAX_REPS=2', 'representation capacity exceeded'),
        ('divisors', 'S4_MAX_DIVS=1', 'divisor capacity exceeded'),
        ('extensions', 'S4_MAX_EXT=1', 'extension capacity exceeded'),
    ]:
        limited = build('s4-limit-'+kind, ['-D'+define])
        run(limited, 'limit-'+kind, 1, 10**9, expected=2)
        assert expected_message in (OUT/('limit-'+kind+'.err')).read_text()
    # Kill after a durable checkpoint, resume, and compare the complete result set.
    checkpoint = OUT/'restart.ckpt'
    output = OUT/'restart.out'
    args = [str(binary), '1', str(10**9), '16', '20', '--verify',
            '--out', str(output), '--ckpt', str(checkpoint)]
    with (OUT/'restart-first.err').open('w') as err:
        p = subprocess.Popen(args, cwd=OUT, stdout=subprocess.DEVNULL, stderr=err)
        deadline = time.monotonic()+20
        while not checkpoint.exists():
            assert p.poll() is None and time.monotonic()<deadline
            time.sleep(0.05)
        assert 'DONE' not in checkpoint.read_text()
        p.terminate(); p.wait(timeout=10)
    with (OUT/'restart-resume.err').open('w') as err:
        subprocess.run(args+['--resume'], cwd=OUT, stdout=subprocess.DEVNULL, stderr=err, check=True)
    assert checkpoint.read_text().endswith('DONE\n')
    assert set(lines(output)) == set(lines(OUT/'small.out'))
    print('checkpoint interruption/resume passed', flush=True)
    run(binary, 'frontier', 10**12, 10**12+10**9, '--verify')
    assert lines(OUT/'frontier.out') == lines(ROOT/'review-2026-09-15/s4_shell_1e12.out')
    summary = {'passed': True, 'checks': ['reference small census', 'three injected capacity failures',
               'interrupted checkpoint/resume result equivalence', 'reference frontier interval'],
               'source_sha256': hashlib.sha256((ROOT/'s4.c').read_bytes()).hexdigest(),
               'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
    (OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()

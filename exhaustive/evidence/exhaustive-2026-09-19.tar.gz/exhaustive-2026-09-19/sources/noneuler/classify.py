#!/usr/bin/env python3
"""classify.py - the exhaustive pseudo-solutions in the K_{3,3} / elliptic-curve language.

A 6-set {n1..n6} split into two triples X = {x1,x2,x3}, Y = {y1,y2,y3} has the 9 cross sums x_a + y_b (a K_{3,3}) and
the 6 sums inside the triples (two triangles).  A 3x3 semi-magic square of squares is the same thing as a K_{3,3} with
square cross sums (entries x_{i+j} + y_{i+2j}).  It is an *Euler* square iff the 3x3 root matrix, with suitable signs,
is orthogonal (rows pairwise orthogonal); then it comes from a rational quaternion.
For fixed X the values y with x1+y, x2+y, x3+y square are the points of 2E(Q) on  E: Y^2 = X(X-d)(X-e),
d = x1-x2, e = x1-x3, via X = x1+y, Y = product of the three roots.  So a K_{3,3} of squares = (d,e) + three points
of 2E(Q).  This script classifies, for every primitive pseudo-solution of the S<10^12 run (six positive integers,
14 of 15 sums square; bad edge {e,f}), the four complete K_{3,3} squares (X = {e,f,a}):
  Euler or not; lambda-related (Lagrange) pairs; the small integer relations  a P1 + b P2 + c P3 in E[2]  among the
  three column points, computed with the exact group law.
usage: python3 classify.py M_lines.txt out.jsonl      (M_lines.txt = the "M:" lines of the s4 output)
"""
import re, sys, json
from fractions import Fraction as F
from math import isqrt, gcd
from itertools import combinations, product
from functools import reduce

def is_sq(n): return n >= 0 and isqrt(n) ** 2 == n
def sqf_scale(g):
    k = 1; d = 2
    while d * d <= g:
        while g % (d * d) == 0: g //= d * d; k *= d
        d += 1
    return k

def load(path):
    prims = {}
    for line in open(path):
        m = re.match(r"M: \[([\d,]+)\] ext=\[([\d,]+)\]", line)
        if not m: continue
        four = tuple(map(int, m.group(1).split(","))); ext = tuple(map(int, m.group(2).split(",")))
        for e, f in combinations(ext, 2):
            if is_sq(e + f): continue          # would be a 6-set
            allv = four + (e, f); g = reduce(gcd, allv); k = sqf_scale(g); k2 = k * k
            rep = tuple(sorted(v // k2 for v in allv)); prims[rep] = tuple(sorted((e // k2, f // k2)))
    return prims

# ---------- Euler test ----------
def latin_square(x, y):
    """3x3 semi-magic square S[i][j] = x[(i+j)%3] + y[(i+2j)%3] and its positive roots."""
    S = [[x[(i + j) % 3] + y[(i + 2 * j) % 3] for j in range(3)] for i in range(3)]
    R = [[isqrt(v) for v in row] for row in S]
    assert all(R[i][j] ** 2 == S[i][j] for i in range(3) for j in range(3))
    return S, R

def euler_signs(R):
    """signs s (3x3 of +-1) with (s*R)(s*R)^T diagonal, first row +; None if none."""
    for bits in range(64):
        s = [[1, 1, 1], [1, 1, 1], [1, 1, 1]]
        for k in range(6): s[1 + k // 3][k % 3] = -1 if (bits >> k) & 1 else 1
        ok = True
        for i, k in ((0, 1), (0, 2), (1, 2)):
            if sum(s[i][j] * s[k][j] * R[i][j] * R[k][j] for j in range(3)) != 0: ok = False; break
        if ok: return s
    return None

def quaternion(R, s, M):
    """rational quaternion (integers, gcd 1) of the rotation Q = (s*R)/N, N^2 = M."""
    N = isqrt(M); assert N * N == M
    Q = [[F(s[i][j] * R[i][j], N) for j in range(3)] for i in range(3)]
    det = (Q[0][0] * (Q[1][1] * Q[2][2] - Q[1][2] * Q[2][1]) - Q[0][1] * (Q[1][0] * Q[2][2] - Q[1][2] * Q[2][0])
           + Q[0][2] * (Q[1][0] * Q[2][1] - Q[1][1] * Q[2][0]))
    if det < 0: Q = [[-v for v in row] for row in Q]
    tr = Q[0][0] + Q[1][1] + Q[2][2]
    cands = [(1 + tr, Q[2][1] - Q[1][2], Q[0][2] - Q[2][0], Q[1][0] - Q[0][1]),           # (t^2, tu, tv, tw)*4
             (Q[2][1] - Q[1][2], 1 + 2 * Q[0][0] - tr, Q[0][1] + Q[1][0], Q[0][2] + Q[2][0]),  # (tu, u^2, uv, uw)*4
             (Q[0][2] - Q[2][0], Q[0][1] + Q[1][0], 1 + 2 * Q[1][1] - tr, Q[1][2] + Q[2][1]),  # (tv, uv, v^2, vw)*4
             (Q[1][0] - Q[0][1], Q[0][2] + Q[2][0], Q[1][2] + Q[2][1], 1 + 2 * Q[2][2] - tr)]  # (tw, uw, vw, w^2)*4
    for c in cands:
        if any(v != 0 for v in c):
            den = reduce(lambda a, b: a * b // gcd(a, b), [v.denominator for v in c])
            q = [int(v * den) for v in c]; g = reduce(gcd, [abs(v) for v in q]); q = [v // g for v in q]
            if q[0] < 0 or (q[0] == 0 and next(v for v in q if v) < 0): q = [-v for v in q]
            return tuple(q)
    return None

def euler_entries(t, u, v, w):
    """the 9 entries (squares) of Euler's square for quaternion (t,u,v,w), magic sum (t^2+u^2+v^2+w^2)^2."""
    R = [[t*t+u*u-v*v-w*w, 2*(u*v-t*w), 2*(u*w+t*v)], [2*(u*v+t*w), t*t-u*u+v*v-w*w, 2*(v*w-t*u)],
         [2*(u*w-t*v), 2*(v*w+t*u), t*t-u*u-v*v+w*w]]
    return sorted(R[i][j] ** 2 for i in range(3) for j in range(3))

def lambda_candidates(q):
    """the three lambda-squares of quaternion q (Lagrange): scale one pair of coordinates by
    lambda = (sum of squares of the other pair)/(sum of squares of the pair); returned normalised to magic sum 1."""
    t, u, v, w = [F(z) for z in q]; out = []
    for (i, j) in ((1, 2), (0, 3), (0, 2), (1, 3), (0, 1), (2, 3)):
        c = [t, u, v, w]; k, l = [m for m in range(4) if m not in (i, j)]
        den = c[i] ** 2 + c[j] ** 2
        if den == 0: continue
        lam = (c[k] ** 2 + c[l] ** 2) / den
        c[i] *= lam; c[j] *= lam
        E = euler_entries(*c); Msum = sum(E[:3]) if False else None
        # magic sum of an Euler square = (sum of squares)^2
        Mq = (c[0] ** 2 + c[1] ** 2 + c[2] ** 2 + c[3] ** 2) ** 2
        out.append(tuple(sorted(v / Mq for v in E)))
    return out

# ---------- elliptic curve E: Y^2 = X^3 + a2 X^2 + a4 X ----------
class Curve:
    def __init__(self, d, e): self.a2 = F(-(d + e)); self.a4 = F(d * e); self.d = d; self.e = e
    def on(self, P):
        if P is None: return True
        x, y = P; return y * y == x ** 3 + self.a2 * x * x + self.a4 * x
    def neg(self, P): return None if P is None else (P[0], -P[1])
    def add(self, P, Q):
        if P is None: return Q
        if Q is None: return P
        x1, y1 = P; x2, y2 = Q
        if x1 == x2:
            if y1 + y2 == 0: return None
            lam = (3 * x1 * x1 + 2 * self.a2 * x1 + self.a4) / (2 * y1)
        else:
            lam = (y2 - y1) / (x2 - x1)
        x3 = lam * lam - self.a2 - x1 - x2
        y3 = lam * (x1 - x3) - y1
        return (x3, y3)
    def mul(self, n, P):
        if n < 0: return self.mul(-n, self.neg(P))
        R = None; Q = P
        while n:
            if n & 1: R = self.add(R, Q)
            Q = self.add(Q, Q); n >>= 1
        return R
    def torsion2_name(self, P):
        if P is None: return "O"
        if P[1] != 0: return None
        return {F(0): "T0", F(self.d): "Td", F(self.e): "Te"}.get(P[0], "T?")

def relations(E, pts, bound=3):
    """all (a,b,c) with |.|<=bound, gcd 1, first nonzero positive, such that a P1 + b P2 + c P3 is O or 2-torsion."""
    mults = [{m: E.mul(m, P) for m in range(-bound, bound + 1)} for P in pts]
    rels = []
    for a, b, c in product(range(-bound, bound + 1), repeat=3):
        if (a, b, c) == (0, 0, 0): continue
        if reduce(gcd, [abs(a), abs(b), abs(c)]) != 1: continue
        first = next(v for v in (a, b, c) if v)
        if first < 0: continue
        R = E.add(E.add(mults[0][a], mults[1][b]), mults[2][c])
        t = E.torsion2_name(R)
        if t: rels.append((a, b, c, t))
    rels.sort(key=lambda r: (abs(r[0]) + abs(r[1]) + abs(r[2]), r))
    return rels

def analyse_square(x, y):
    """x,y: triples with all 9 cross sums square. Returns dict with Euler data and curve relations."""
    M = sum(x) + sum(y)
    S, R = latin_square(x, y)
    s = euler_signs(R)
    q = quaternion(R, s, M) if (s is not None and is_sq(M)) else None
    d, e = x[0] - x[1], x[0] - x[2]
    E = Curve(d, e)
    pts = []
    for b in range(3):
        X = F(x[0] + y[b]); Y = F(isqrt(x[0] + y[b]) * isqrt(x[1] + y[b]) * isqrt(x[2] + y[b]))
        assert E.on((X, Y)); pts.append((X, Y))
    rels = relations(E, pts)
    return {"x": list(x), "y": list(y), "M": M, "euler": s is not None, "q": q, "d": d, "e": e,
            "X": [int(p[0]) for p in pts], "Y": [int(p[1]) for p in pts], "rels": rels[:6]}

def main():
    prims = load(sys.argv[1]); out = open(sys.argv[2], "w")
    print("primitive pseudo-solutions:", len(prims), " square total:", sum(1 for s in prims if is_sq(sum(s))))
    stats = {"n_euler_hist": {}, "lam_pairs": 0, "sq_total": 0, "rel_euler": {}, "rel_noneuler": {}}
    n_sq = 0
    for s6, bad in sorted(prims.items()):
        others = [v for v in s6 if v not in bad]
        squares = []
        for a in others:
            x = (bad[0], bad[1], a); y = tuple(v for v in others if v != a)
            squares.append(analyse_square(x, y))
        ne = sum(1 for sq in squares if sq["euler"])
        stats["n_euler_hist"][ne] = stats["n_euler_hist"].get(ne, 0) + 1
        # lambda relations among Euler pairs (compare normalised entry multisets)
        lam = 0
        eul = [sq for sq in squares if sq["q"]]
        norm = {}
        for sq in eul:
            S, _ = latin_square(sq["x"], sq["y"]); norm[id(sq)] = tuple(sorted(F(v, sq["M"]) for row in S for v in row))
        for A, B in combinations(eul, 2):
            if norm[id(B)] in lambda_candidates(A["q"]) or norm[id(A)] in lambda_candidates(B["q"]): lam += 1
        stats["lam_pairs"] += lam
        for sq in squares:
            key = "euler" if sq["euler"] else "noneuler"
            r = sq["rels"][0] if sq["rels"] else None
            rk = "none" if r is None else "%d,%d,%d->%s" % tuple(r)
            stats["rel_" + key][rk] = stats["rel_" + key].get(rk, 0) + 1
        rec = {"set": list(s6), "bad": list(bad), "square_total": is_sq(sum(s6)), "n_euler": ne, "lambda_pairs": lam,
               "squares": squares}
        out.write(json.dumps(rec) + "\n"); n_sq += len(squares)
    out.close()
    print("squares analysed:", n_sq)
    print("pseudo-solutions by number of Euler squares among the 4:", dict(sorted(stats["n_euler_hist"].items())))
    print("lambda-related Euler pairs (Lagrange type):", stats["lam_pairs"])
    for key in ("rel_euler", "rel_noneuler"):
        items = sorted(stats[key].items(), key=lambda kv: -kv[1])
        print(key, "(smallest relation a P1+b P2+c P3 = torsion):", items[:12])

if __name__ == "__main__":
    main()

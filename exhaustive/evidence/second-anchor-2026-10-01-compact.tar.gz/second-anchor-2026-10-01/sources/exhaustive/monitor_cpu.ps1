param(
    [Parameter(Mandatory=$true)][string]$RunDirectory,
    [Parameter(Mandatory=$true)][int]$LauncherPid,
    [Parameter(Mandatory=$true)][string]$Deadline,
    [int]$MaximumCpus = 10,
    [double]$Target = 70
)
$ErrorActionPreference = 'Stop'
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class SearchHostCpu {
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool GetSystemTimes(out long idle, out long kernel, out long user);
    public static long[] Read() {
        long idle, kernel, user;
        if (!GetSystemTimes(out idle, out kernel, out user))
            throw new System.ComponentModel.Win32Exception();
        return new long[] {idle, kernel + user};
    }
}
'@
$taskUntil = [DateTimeOffset]::Parse($Deadline)
$taskCpus = [Math]::Min(8, $MaximumCpus)
$taskLogical = [Environment]::ProcessorCount
$taskPrevious = [SearchHostCpu]::Read()
$taskUtf8 = New-Object System.Text.UTF8Encoding($false)
$taskPath = Join-Path $RunDirectory 'cpu-control.json'
$taskTemp = Join-Path $RunDirectory 'cpu-control.json.pending'
while ([DateTimeOffset]::UtcNow -lt $taskUntil -and (Get-Process -Id $LauncherPid -ErrorAction SilentlyContinue)) {
    $taskNow = [DateTimeOffset]::UtcNow
    $taskRecord = @{ updated_epoch = $taskNow.ToUnixTimeMilliseconds()/1000.0; updated_at = $taskNow.ToString('o'); allowed_cpus = [int]$taskCpus; target_percent = $Target; maximum_cpus = $MaximumCpus; host_cpu_percent = $taskLoad; monitor_pid = $PID }
    $taskJson = $taskRecord | ConvertTo-Json -Compress
    [System.IO.File]::WriteAllText($taskTemp, $taskJson, $taskUtf8)
    if ([System.IO.File]::Exists($taskPath)) { [System.IO.File]::Replace($taskTemp, $taskPath, $null) }
    else { [System.IO.File]::Move($taskTemp, $taskPath) }
    [System.IO.File]::AppendAllText((Join-Path $RunDirectory 'cpu-load.jsonl'), $taskJson+[Environment]::NewLine, $taskUtf8)
    Start-Sleep -Seconds 10
    $taskCurrent = [SearchHostCpu]::Read()
    $taskTotal = $taskCurrent[1]-$taskPrevious[1]
    if ($taskTotal -le 0) { throw 'Invalid CPU timing sample' }
    $taskLoad = [Math]::Max(0, [Math]::Min(100, 100*(1-($taskCurrent[0]-$taskPrevious[0])/[double]$taskTotal)))
    $taskPrevious = $taskCurrent
    if ($taskLoad -gt $Target+4) {
        $taskDrop = [Math]::Max(1, [int][Math]::Ceiling(($taskLoad-$Target)/100*$taskLogical))
        $taskCpus = [Math]::Max(1, $taskCpus-$taskDrop)
    } elseif ($taskLoad -lt $Target-4) {
        $taskCpus = [Math]::Min($MaximumCpus, $taskCpus+1)
    }
}

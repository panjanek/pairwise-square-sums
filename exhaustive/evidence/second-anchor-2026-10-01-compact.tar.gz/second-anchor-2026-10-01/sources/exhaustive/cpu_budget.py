"""Apply host-requested CPU concurrency without changing enumeration partitions."""
from pathlib import Path
import json
import os
import time
import math


def read_budget(path, maximum, now=None):
    now = time.time() if now is None else now
    fallback = min(4, maximum)
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        age = now-float(data['updated_epoch'])
        count = data['allowed_cpus']
        load = data['host_cpu_percent']
        assert type(load) in (int, float) and math.isfinite(load) and 0 <= load <= 100
        assert type(count) is int and 1 <= count <= maximum and -5 <= age <= 45
        return count, 'host_feedback'
    except (OSError, ValueError, KeyError, TypeError, AssertionError):
        return fallback, 'stale_or_invalid_feedback'


def apply_affinity(pid, cpus):
    # Linux affinity is per thread; cover every C worker, not only its leader.
    applied = 0
    for task in (Path('/proc')/str(pid)/'task').glob('*'):
        try:
            os.sched_setaffinity(int(task.name), cpus)
            applied += 1
        except ProcessLookupError:
            pass  # A thread may finish between enumeration and the syscall.
    return applied
